#include <iostream>
#include <queue>
#include <stack>
using namespace std;
queue<int> roadQueue;
stack<int> garageStack;

// Truck enters road
void On_road(int truck_id) {
    roadQueue.push(truck_id);
    cout << "Truck " << truck_id << " is on the road.\n";
}
void Enter_garage(int truck_id) {
    if (!roadQueue.empty() && roadQueue.front() == truck_id) {
        roadQueue.pop();
        garageStack.push(truck_id);
        cout << "Truck " << truck_id << " entered the garage.\n";
    } else {
        cout << "Truck " << truck_id << " is not at the front of the road.\n";
    }
}
void Exit_garage(int truck_id) {
    if (!garageStack.empty() && garageStack.top() == truck_id) {
        garageStack.pop();
        cout << "Truck " << truck_id << " exited the garage.\n";
    } else {
        cout << "Truck is not near garage door!\n";
    }
}
void Show_trucks(string location) {
    if (location == "road") {
        if (roadQueue.empty()) {
            cout << "No trucks on road.\n";
            return;
        }
        cout << "Trucks on road: ";
        queue<int> temp = roadQueue;
        while (!temp.empty()) {
            cout << temp.front() << " ";
            temp.pop();
        }
        cout << endl;
    } else if (location == "garage") {
        if (garageStack.empty()) {
            cout << "No trucks in garage.\n";
            return;
        }
        cout << "Trucks in garage (top to bottom): ";
        stack<int> temp = garageStack;
        while (!temp.empty()) {
            cout << temp.top() << " ";
            temp.pop();
        }
        cout << endl;
    } else {
        cout << "Invalid location. Choose 'road' or 'garage'.\n";
    }
}

int main() {
    int choice, truck_id;
    string location;

    do {
        cout << "\n--- Garage Management Menu ---\n";
        cout << "1. Truck on road\n";
        cout << "2. Enter garage\n";
        cout << "3. Exit garage\n";
        cout << "4. Show trucks\n";
        cout << "0. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
            case 1:
                cout << "Enter truck ID: ";
                cin >> truck_id;
                On_road(truck_id);
                break;
            case 2:
                cout << "Enter truck ID: ";
                cin >> truck_id;
                Enter_garage(truck_id);
                break;
            case 3:
                cout << "Enter truck ID: ";
                cin >> truck_id;
                Exit_garage(truck_id);
                break;
            case 4:
                cout << "Enter location (road/garage): ";
                cin >> location;
                Show_trucks(location);
                break;
            case 0:
                cout << "Exiting program...\n";
                break;
            default:
                cout << "Invalid choice! Try again.\n";
        }
    } while (choice != 0);

    return 0;
}
