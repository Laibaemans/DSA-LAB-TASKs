#include <iostream>
#include <string>
using namespace std;
class Applicant {
public:
    int applicant_id;
    double height;
    double weight;
    double eyesight;
    string status; 

    Applicant() {}
    Applicant(int id, double h, double w, double e, string s) {
        applicant_id = id;
        height = h;
        weight = w;
        eyesight = e;
        status = s;
    }

    void display() {
        cout << "ID: " << applicant_id 
             << ", Height: " << height 
             << ", Weight: " << weight 
             << ", Eyesight: " << eyesight
             << ", Status: " << status << endl;
    }
};
struct Node {
    Applicant data;
    Node* next;
    Node* prev;
};
class Queue {
private:
    Node* front;
    Node* rear;

public:
    Queue() {
        front = rear = nullptr;
    }
    void enqueue(Applicant a) {
        Node* newNode = new Node;
        newNode->data = a;
        newNode->next = nullptr;
        newNode->prev = rear;

        if (!rear) {
            front = rear = newNode;
        } else {
            rear->next = newNode;
            rear = newNode;
        }
    }
    void dequeue() {
        if (!front) {
            cout << "No applicants in the queue!\n";
            return;
        }
        cout << "Applicant leaving after test:\n";
        front->data.status = "Completed";
        front->data.display();

        Node* temp = front;
        front = front->next;
        if (front) front->prev = nullptr;
        else rear = nullptr; 
        delete temp;
    }
    void removeSecond() {
        if (!front || !front->next) {
            cout << "Less than 2 applicants in queue!\n";
            return;
        }
        Node* second = front->next;
        cout << "Applicant leaving from 2nd position due to urgency:\n";
        second->data.display();

        front->next = second->next;
        if (second->next) second->next->prev = front;
        else rear = front; // if 2nd was last node

        delete second;
    }

    // Display queue
    void displayQueue() {
        if (!front) {
            cout << "Queue is empty!\n";
            return;
        }
        cout << "\nCurrent Queue:\n";
        Node* temp = front;
        int pos = 1;
        while (temp) {
            cout << pos << ". ";
            temp->data.display();
            temp = temp->next;
            pos++;
        }
        cout << endl;
    }
};

int main() {
    Queue q;

    // Adding 7 applicants
    q.enqueue(Applicant(101, 170, 65, 1.0, "Pending"));
    q.enqueue(Applicant(102, 165, 60, 0.8, "Pending"));
    q.enqueue(Applicant(103, 172, 70, 1.2, "Pending"));
    q.enqueue(Applicant(104, 168, 68, 0.9, "Pending"));
    q.enqueue(Applicant(105, 175, 75, 1.0, "Pending"));
    q.enqueue(Applicant(106, 160, 55, 0.7, "Pending"));
    q.enqueue(Applicant(107, 180, 80, 1.1, "Pending"));

    q.displayQueue();

    // Applicant at front finishes test
    q.dequeue();
    q.displayQueue();

    // Applicant at 2nd position leaves urgently
    q.removeSecond();
    q.displayQueue();

    return 0;
}
