#include <iostream>
using namespace std;
struct Node {
    float rainfall;
    Node* next;
};
class RainfallList {
private:
    Node* last; // pointer to the last node

public:
    RainfallList() {
        last = nullptr;
    }
    void addAtEnd(float rain) {
        Node* newNode = new Node;
        newNode->rainfall = rain;

        if (last == nullptr) {
            last = newNode;
            last->next = last; // circular connection
        } else {
            newNode->next = last->next;
            last->next = newNode;
            last = newNode;
        }
    }
    void inputRainfall() {
        cout << "Enter total rainfall for 7 days:\n";
        for (int i = 1; i <= 7; i++) {
            float rain;
            do {
                cout << "Day " << i << ": ";
                cin >> rain;
                if (rain < 0)
                    cout << "Invalid input! Rainfall cannot be negative.\n";
            } while (rain < 0);

            addAtEnd(rain);
        }
    }
    void display() {
        if (last == nullptr) {
            cout << "No data available!\n";
            return;
        }

        Node* temp = last->next;
        int day = 1;
        cout << "\nRainfall Data:\n";
        do {
            cout << "Day " << day++ << ": " << temp->rainfall << " mm\n";
            temp = temp->next;
        } while (temp != last->next);
    }
    float totalRainfall() {
        if (last == nullptr)
            return 0;

        float total = 0;
        Node* temp = last->next;
        do {
            total += temp->rainfall;
            temp = temp->next;
        } while (temp != last->next);
        return total;
    }
    float averageRainfall() {
        return totalRainfall() / 7.0;
    }
    void findHighLow() {
        if (last == nullptr) {
            cout << "No data available!\n";
            return;
        }

        Node* temp = last->next;
        float maxRain = temp->rainfall, minRain = temp->rainfall;
        int dayMax = 1, dayMin = 1, day = 1;

        do {
            if (temp->rainfall > maxRain) {
                maxRain = temp->rainfall;
                dayMax = day;
            }
            if (temp->rainfall < minRain) {
                minRain = temp->rainfall;
                dayMin = day;
            }
            temp = temp->next;
            day++;
        } while (temp != last->next);

        cout << "\nHighest rainfall: " << maxRain << " mm (Day " << dayMax << ")";
        cout << "\nLowest rainfall: " << minRain << " mm (Day " << dayMin << ")\n";
    }
    void rainfallAfter5th() {
        if (last == nullptr) {
            cout << "List is empty!\n";
            return;
        }

        Node* temp = last->next;
        int count = 1;

        // Move to 5th node
        while (count < 5 && temp->next != last->next) {
            temp = temp->next;
            count++;
        }

        cout << "\nRainfall of day **after 5th node**: " << temp->next->rainfall << " mm\n";
    }
};
int main() {
    RainfallList week;

    week.inputRainfall();
    week.display();

    cout << "\nTotal rainfall for the week: " << week.totalRainfall() << " mm";
    cout << "\nAverage weekly rainfall: " << week.averageRainfall() << " mm";

    week.findHighLow();
    week.rainfallAfter5th();

    return 0;
}
