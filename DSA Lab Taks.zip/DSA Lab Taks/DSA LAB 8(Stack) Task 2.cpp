#include <iostream>
using namespace std;

// Inventory class
class Inventory {
private:
    int serialNum;
    int manufactYear;
    int lotNum;

public:
    // Function to set data
    void setData(int s, int y, int l) {
        serialNum = s;
        manufactYear = y;
        lotNum = l;
    }

    // Function to display data
    void displayData() {
        cout << "Serial Number: " << serialNum 
             << ", Manufacture Year: " << manufactYear 
             << ", Lot Number: " << lotNum << endl;
    }
};
struct Node {
    Inventory part;
    Node* next;
};

class Stack {
private:
    Node* top;

public:
    Stack() {
        top = nullptr;
    }
    void push(Inventory p) {
        Node* newNode = new Node;
        newNode->part = p;
        newNode->next = top;
        top = newNode;
    }
    void pop() {
        if (!top) {
            cout << "Inventory is empty!\n";
            return;
        }
        cout << "Removing the following part from inventory:\n";
        top->part.displayData();
        Node* temp = top;
        top = top->next;
        delete temp;
    }
    void displayStack() {
        if (!top) {
            cout << "Inventory is empty!\n";
            return;
        }
        cout << "\nRemaining parts in inventory:\n";
        Node* temp = top;
        while (temp) {
            temp->part.displayData();
            temp = temp->next;
        }
    }

    // Check if stack is empty
    bool isEmpty() {
        return top == nullptr;
    }
};

int main() {
    Stack inventoryStack;
    int choice;

    do {
        cout << "\n--- Inventory Menu ---\n";
        cout << "1. Add part to inventory\n";
        cout << "2. Take part from inventory\n";
        cout << "0. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        if (choice == 1) {
            int serial, year, lot;
            cout << "Enter Serial Number: ";
            cin >> serial;
            cout << "Enter Manufacture Year: ";
            cin >> year;
            cout << "Enter Lot Number: ";
            cin >> lot;

            Inventory newPart;
            newPart.setData(serial, year, lot);
            inventoryStack.push(newPart);
        } 
        else if (choice == 2) {
            inventoryStack.pop();
        } 
        else if (choice != 0) {
            cout << "Invalid choice! Try again.\n";
        }

    } while (choice != 0);

    inventoryStack.displayStack();

    return 0;
}
