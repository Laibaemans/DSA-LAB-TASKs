#include <iostream>
using namespace std;

// Node structure
struct Node {
    int marks;
    Node* prev;
    Node* next;
};

// Function to create a new node
Node* createNode(int data) {
    Node* newNode = new Node();
    newNode->marks = data;
    newNode->prev = nullptr;
    newNode->next = nullptr;
    return newNode;
}

// Function to initialize the doubly linked list from user input
Node* initializeList(int n) {
    Node* head = nullptr;
    Node* tail = nullptr;
    for (int i = 0; i < n; i++) {
        int mark;
        cout << "Enter marks for node " << i+1 << ": ";
        cin >> mark;
        Node* newNode = createNode(mark);
        if (!head) {
            head = tail = newNode;
        } else {
            tail->next = newNode;
            newNode->prev = tail;
            tail = newNode;
        }
    }
    return head;
}

// Function to display the list
void displayList(Node* head) {
    Node* temp = head;
    cout << "Doubly Linked List: ";
    while (temp) {
        cout << temp->marks << " ";
        temp = temp->next;
    }
    cout << endl;
}

// Function to add a node at the beginning
Node* addAtBeginning(Node* head, int data) {
    Node* newNode = createNode(data);
    if (head) {
        newNode->next = head;
        head->prev = newNode;
    }
    head = newNode;
    return head;
}

// Function to add a node after node with value 45
void addAfterValue(Node* head, int value, int data) {
    Node* temp = head;
    while (temp && temp->marks != value) {
        temp = temp->next;
    }
    if (!temp) {
        cout << "Value " << value << " not found in the list.\n";
        return;
    }
    Node* newNode = createNode(data);
    newNode->next = temp->next;
    newNode->prev = temp;
    if (temp->next) {
        temp->next->prev = newNode;
    }
    temp->next = newNode;
}

// Function to delete node at beginning
Node* deleteAtBeginning(Node* head) {
    if (!head) {
        cout << "List is empty!\n";
        return nullptr;
    }
    Node* temp = head;
    head = head->next;
    if (head) {
        head->prev = nullptr;
    }
    delete temp;
    return head;
}

// Function to delete node after node with value 45
void deleteAfterValue(Node* head, int value) {
    Node* temp = head;
    while (temp && temp->marks != value) {
        temp = temp->next;
    }
    if (!temp || !temp->next) {
        cout << "No node exists after value " << value << " to delete.\n";
        return;
    }
    Node* delNode = temp->next;
    temp->next = delNode->next;
    if (delNode->next) {
        delNode->next->prev = temp;
    }
    delete delNode;
}

int main() {
    int n;
    cout << "Enter number of nodes: ";
    cin >> n;

    Node* head = initializeList(n);
    displayList(head);

    cout << "\nAdding 100 at beginning...\n";
    head = addAtBeginning(head, 100);
    displayList(head);

    cout << "\nAdding 200 after node with value 45...\n";
    addAfterValue(head, 45, 200);
    displayList(head);

    cout << "\nDeleting node at beginning...\n";
    head = deleteAtBeginning(head);
    displayList(head);

    cout << "\nDeleting node after value 45...\n";
    deleteAfterValue(head, 45);
    displayList(head);

    return 0;
}
