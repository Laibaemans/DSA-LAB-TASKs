#include <iostream>
#include <string>
using namespace std;
struct Player {
    string name;
    int score;
    Player* next;
    Player* prev;
};
class GolfTournament {
private:
    Player* head;  // points to first player (lowest score)
public:
    GolfTournament() {
        head = nullptr;
    }
    void addPlayer(string name, int score) {
        Player* newNode = new Player;
        newNode->name = name;
        newNode->score = score;

        if (head == nullptr) {
            // First player
            newNode->next = newNode->prev = newNode;
            head = newNode;
            cout << "Player added successfully.\n";
            return;
        }

        Player* temp = head;
        do {
            if (score < temp->score) {
                newNode->next = temp;
                newNode->prev = temp->prev;
                temp->prev->next = newNode;
                temp->prev = newNode;
                if (temp == head)
                    head = newNode;  // new lowest score becomes head
                cout << "Player added successfully.\n";
                return;
            }
            temp = temp->next;
        } while (temp != head);
        newNode->next = head;
        newNode->prev = head->prev;
        head->prev->next = newNode;
        head->prev = newNode;
        cout << "Player added successfully.\n";
    }
    void deletePlayer(string name) {
        if (head == nullptr) {
            cout << "List is empty!\n";
            return;
        }

        Player* temp = head;
        do {
            if (temp->name == name) {
                if (temp->next == temp && temp->prev == temp) {
                    // Only one player
                    delete temp;
                    head = nullptr;
                    cout << "Player deleted successfully.\n";
                    return;
                }
                temp->prev->next = temp->next;
                temp->next->prev = temp->prev;
                if (temp == head)
                    head = temp->next;
                delete temp;
                cout << "Player deleted successfully.\n";
                return;
            }
            temp = temp->next;
        } while (temp != head);

        cout << "Player not found!\n";
    }
    void displayAll() {
        if (head == nullptr) {
            cout << "No players available!\n";
            return;
        }

        Player* temp = head;
        cout << "\n--- Players List (Ascending by Score) ---\n";
        do {
            cout << "Name: " << temp->name << ", Score: " << temp->score << endl;
            temp = temp->next;
        } while (temp != head);
        cout << "-----------------------------------------\n";
    }
    void displayLowestScore() {
        if (head == nullptr) {
            cout << "No players available!\n";
            return;
        }
        cout << "\nPlayer with lowest score:\n";
        cout << "Name: " << head->name << ", Score: " << head->score << endl;
    }
    void displaySameScore(int score) {
        if (head == nullptr) {
            cout << "No players available!\n";
            return;
        }

        bool found = false;
        Player* temp = head;
        cout << "\nPlayers having score " << score << ":\n";
        do {
            if (temp->score == score) {
                cout << "Name: " << temp->name << ", Score: " << temp->score << endl;
                found = true;
            }
            temp = temp->next;
        } while (temp != head);

        if (!found)
            cout << "No player found with this score.\n";
    }
    void displayBackwardFrom(string name) {
        if (head == nullptr) {
            cout << "No players available!\n";
            return;
        }

        Player* temp = head;
        bool found = false;

        do {
            if (temp->name == name) {
                found = true;
                break;
            }
            temp = temp->next;
        } while (temp != head);

        if (!found) {
            cout << "Player not found!\n";
            return;
        }

        cout << "\nDisplaying backward from player: " << name << endl;
        Player* back = temp->prev;
        while (back != temp) {
            cout << "Name: " << back->name << ", Score: " << back->score << endl;
            back = back->prev;
        }
    }
};
int main() {
    GolfTournament gt;
    int choice;
    string name;
    int score;

    do {
        cout << "\n================ Golf Tournament Menu ================\n";
        cout << "1. Add new Player (sorted by score)\n";
        cout << "2. Delete a Player\n";
        cout << "3. Display all Players\n";
        cout << "4. Display player with lowest score\n";
        cout << "5. Display players with same score\n";
        cout << "6. Display backward from a player\n";
        cout << "0. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
        case 1:
            cout << "Enter player name: ";
            cin >> name;
            cout << "Enter player score: ";
            cin >> score;
            gt.addPlayer(name, score);
            break;

        case 2:
            cout << "Enter name of player to delete: ";
            cin >> name;
            gt.deletePlayer(name);
            break;

        case 3:
            gt.displayAll();
            break;

        case 4:
            gt.displayLowestScore();
            break;

        case 5:
            cout << "Enter score to search: ";
            cin >> score;
            gt.displaySameScore(score);
            break;

        case 6:
            cout << "Enter player name to start backward display: ";
            cin >> name;
            gt.displayBackwardFrom(name);
            break;

        case 0:
            cout << "Exiting program...\n";
            break;

        default:
            cout << "Invalid choice! Try again.\n";
        }
    } while (choice != 0);

    return 0;
}
