#include <iostream>
#include <string>
using namespace std;

// Book class
class Book {
public:
    string title;
    double price;
    string edition;
    int pages;

    // Constructor
    Book() {}
    Book(string t, double p, string e, int pg) {
        title = t;
        price = p;
        edition = e;
        pages = pg;
    }

    void display() {
        cout << "Title: " << title 
             << ", Price: $" << price
             << ", Edition: " << edition
             << ", Pages: " << pages << endl;
    }
};

// Node for stack
struct Node {
    Book book;
    Node* next;
};

// Stack class using linked list
class Stack {
private:
    Node* top;

public:
    Stack() {
        top = nullptr;
    }

    // Push a book onto the stack
    void push(Book b) {
        Node* newNode = new Node;
        newNode->book = b;
        newNode->next = top;
        top = newNode;
    }

    // Pop the top book from the stack
    void pop() {
        if (!top) {
            cout << "Stack is empty!\n";
            return;
        }
        cout << "Popping book:\n";
        top->book.display();
        Node* temp = top;
        top = top->next;
        delete temp;
    }

    // Peek at the top book
    void peek() {
        if (!top) {
            cout << "Stack is empty!\n";
            return;
        }
        cout << "Top book in stack:\n";
        top->book.display();
    }

    // Display all books in the stack
    void displayStack() {
        if (!top) {
            cout << "Stack is empty!\n";
            return;
        }
        cout << "\nBooks in stack:\n";
        Node* temp = top;
        while (temp) {
            temp->book.display();
            temp = temp->next;
        }
    }
};

int main() {
    Stack bookStack;

    bookStack.push(Book("C++ Programming", 29.99, "3rd", 450));
    bookStack.push(Book("Data Structures", 35.50, "2nd", 520));
    bookStack.push(Book("Algorithms", 40.00, "1st", 600));
    bookStack.push(Book("Database Systems", 45.25, "4th", 700));
    bookStack.push(Book("Operating Systems", 50.00, "5th", 800));

    bookStack.peek();

    // 3. Pop 2 books from stack
    bookStack.pop();
    bookStack.pop();
    bookStack.displayStack();

    return 0;
}
