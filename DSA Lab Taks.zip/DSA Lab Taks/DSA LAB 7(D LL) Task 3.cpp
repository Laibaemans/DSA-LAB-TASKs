#include <iostream>
#include <string>
using namespace std;
struct Player {
    string name;
    int score;
    Player* next;
    Player* prev;
};
Player* createPlayer(string name, int score) {
    Player* newPlayer = new Player();
    newPlayer->name = name;
    newPlayer->score = score;
    newPlayer->next = nullptr;
    newPlayer->prev = nullptr;
    return newPlayer;
}
Player* addPlayer(Player* head, string name, int score) {
    Player* newPlayer = createPlayer(name, score);
    
    if (!head) return newPlayer;

    if (score < head->score) {
        newPlayer->next = head;
        head->prev = newPlayer;
        return newPlayer;
    }

    Player* temp = head;
    while (temp->next && temp->next->score <= score) {
        temp = temp->next;
    }

    newPlayer->next = temp->next;
    if (temp->next) temp->next->prev = newPlayer;
    temp->next = newPlayer;
    newPlayer->prev = temp;

    return head;
}

// Function to delete a player by name
Player* deletePlayer(Player* head, string name) {
    if (!head) {
        cout << "List is empty!\n";
        return head;
    }

    Player* temp = head;
    while (temp && temp->name != name) {
        temp = temp->next;
    }

    if (!temp) {
        cout << "Player not found!\n";
        return head;
    }

    if (temp->prev) temp->prev->next = temp->next;
    else head = temp->next; 

    if (temp->next) temp->next->prev = temp->prev;

    delete temp;
    cout << "Player deleted successfully.\n";
    return head;
}
void displayList(Player* head) {
    if (!head) {
        cout << "List is empty!\n";
        return;
    }
    cout << "\nPlayers List:\n";
    Player* temp = head;
    while (temp) {
        cout << temp->name << " - " << temp->score << "\n";
        temp = temp->next;
    }
}

// Function to display player(s) with lowest score
void displayLowestScore(Player* head) {
    if (!head) {
        cout << "List is empty!\n";
        return;
    }
    int lowest = head->score;
    cout << "\nPlayer(s) with lowest score (" << lowest << "):\n";
    Player* temp = head;
    while (temp && temp->score == lowest) {
        cout << temp->name << "\n";
        temp = temp->next;
    }
}

// Function to display players with a given score
void displayPlayersWithScore(Player* head, int score) {
    if (!head) {
        cout << "List is empty!\n";
        return;
    }
    cout << "\nPlayers with score " << score << ":\n";
    Player* temp = head;
    bool found = false;
    while (temp) {
        if (temp->score == score) {
            cout << temp->name << "\n";
            found = true;
        }
        temp = temp->next;
    }
    if (!found) cout << "No players found with score " << score << ".\n";
}

// Function to display backward from a given player
void displayBackwardFrom(Player* head, string name) {
    if (!head) {
        cout << "List is empty!\n";
        return;
    }

    Player* temp = head;
    while (temp && temp->name != name) {
        temp = temp->next;
    }

    if (!temp) {
        cout << "Player not found!\n";
        return;
    }

    cout << "\nPlayers behind " << name << ":\n";
    while (temp) {
        cout << temp->name << " - " << temp->score << "\n";
        temp = temp->prev;
    }
}

int main() {
    Player* head = nullptr;
    int choice;
    string name;
    int score;

    do {
        cout << "\n--- Golf Tournament Menu ---\n";
        cout << "1. Add new player\n";
        cout << "2. Delete player\n";
        cout << "3. Display all players\n";
        cout << "4. Display player(s) with lowest score\n";
        cout << "5. Display all players with a specific score\n";
        cout << "6. Display backward from a player\n";
        cout << "0. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch(choice) {
            case 1:
                cout << "Enter player's name: ";
                cin >> ws;
                getline(cin, name);
                cout << "Enter player's score: ";
                cin >> score;
                head = addPlayer(head, name, score);
                break;
            case 2:
                cout << "Enter player's name to delete: ";
                cin >> ws;
                getline(cin, name);
                head = deletePlayer(head, name);
                break;
            case 3:
                displayList(head);
                break;
            case 4:
                displayLowestScore(head);
                break;
            case 5:
                cout << "Enter score to search: ";
                cin >> score;
                displayPlayersWithScore(head, score);
                break;
            case 6:
                cout << "Enter player's name to display backward from: ";
                cin >> ws;
                getline(cin, name);
                displayBackwardFrom(head, name);
                break;
            case 0:
                cout << "Exiting...\n";
                break;
            default:
                cout << "Invalid choice! Try again.\n";
        }
    } while (choice != 0);

    return 0;
}
