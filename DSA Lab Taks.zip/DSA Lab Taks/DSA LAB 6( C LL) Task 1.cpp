#include <iostream>
using namespace std;
struct Node {
    int marks;
    Node* next;
};
class CircularList {
private:
    Node* last; 
public:
    CircularList() {
        last = nullptr;
    }
    void createList(int n) {
        if (n <= 0) {
            cout << "Invalid size!\n";
            return;
        }

        for (int i = 0; i < n; i++) {
            int val;
            cout << "Enter marks " << i + 1 << ": ";
            cin >> val;
            addAtEnd(val);
        }
    }
    void addAtEnd(int val) {
        Node* newNode = new Node;
        newNode->marks = val;
        if (last == nullptr) {
            last = newNode;
            last->next = last;
        } else {
            newNode->next = last->next;
            last->next = newNode;
            last = newNode;
        }
    }
    void addAtBeginning(int val) {
        Node* newNode = new Node;
        newNode->marks = val;
        if (last == nullptr) {
            last = newNode;
            last->next = last;
        } else {
            newNode->next = last->next;
            last->next = newNode;
        }
    }
    void addAfterValue(int key, int val) {
        if (last == nullptr) {
            cout << "List is empty!\n";
            return;
        }

        Node* temp = last->next;
        do {
            if (temp->marks == key) {
                Node* newNode = new Node;
                newNode->marks = val;
                newNode->next = temp->next;
                temp->next = newNode;
                if (temp == last)
                    last = newNode;
                return;
            }
            temp = temp->next;
        } while (temp != last->next);

        cout << "Value " << key << " not found in list!\n";
    }
    void deleteAtBeginning() {
        if (last == nullptr) {
            cout << "List is empty!\n";
            return;
        }

        Node* temp = last->next;
        if (last == last->next) {
            delete last;
            last = nullptr;
        } else {
            last->next = temp->next;
            delete temp;
        }
    }
    void deleteAfterValue(int key) {
        if (last == nullptr) {
            cout << "List is empty!\n";
            return;
        }

        Node* temp = last->next;
        do {
            if (temp->marks == key) {
                Node* delNode = temp->next;
                if (delNode == last)
                    last = temp;
                if (delNode == temp) { // only one node
                    last = nullptr;
                    delete delNode;
                    return;
                }
                temp->next = delNode->next;
                delete delNode;
                return;
            }
            temp = temp->next;
        } while (temp != last->next);

        cout << "Value " << key << " not found!\n";
    }
    void display() {
        if (last == nullptr) {
            cout << "List is empty!\n";
            return;
        }

        Node* temp = last->next;
        cout << "Circular List: ";
        do {
            cout << temp->marks << " ";
            temp = temp->next;
        } while (temp != last->next);
        cout << endl;
    }
};
int main() {
    CircularList list;
    int n;

    cout << "Enter number of nodes: ";
    cin >> n;
    list.createList(n);
    list.display();

    cout << "\nInserting at beginning...\n";
    list.addAtBeginning(99);
    list.display();

    cout << "\nInserting after value 45...\n";
    list.addAfterValue(45, 77);
    list.display();

    cout << "\nDeleting at beginning...\n";
    list.deleteAtBeginning();
    list.display();

    cout << "\nDeleting node after value 45...\n";
    list.deleteAfterValue(45);
    list.display();

    return 0;
}
