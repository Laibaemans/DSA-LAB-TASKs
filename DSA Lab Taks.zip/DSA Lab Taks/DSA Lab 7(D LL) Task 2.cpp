#include <iostream>
using namespace std;
struct Node {
    double rainfall;
    Node* prev;
    Node* next;
};
Node* createNode(double data) {
    Node* newNode = new Node();
    newNode->rainfall = data;
    newNode->prev = nullptr;
    newNode->next = nullptr;
    return newNode;
}
Node* appendNode(Node* head, double data) {
    Node* newNode = createNode(data);
    if (!head) {
        return newNode;
    }
    Node* temp = head;
    while (temp->next) {
        temp = temp->next;
    }
    temp->next = newNode;
    newNode->prev = temp;
    return head;
}
void displayList(Node* head) {
    Node* temp = head;
    int day = 1;
    while (temp) {
        cout << "Day " << day << ": " << temp->rainfall << "mm\n";
        temp = temp->next;
        day++;
    }
}
void calculateStats(Node* head) {
    double total = 0;
    Node* temp = head;
    double maxRain = temp->rainfall;
    double minRain = temp->rainfall;
    int maxDay = 1, minDay = 1;
    int day = 1;

    while (temp) {
        total += temp->rainfall;
        if (temp->rainfall > maxRain) {
            maxRain = temp->rainfall;
            maxDay = day;
        }
        if (temp->rainfall < minRain) {
            minRain = temp->rainfall;
            minDay = day;
        }
        temp = temp->next;
        day++;
    }

    cout << "\nTotal rainfall for the week: " << total << " mm\n";
    cout << "Average weekly rainfall: " << total / 7 << " mm\n";
    cout << "Day with highest rainfall: Day " << maxDay << " (" << maxRain << " mm)\n";
    cout << "Day with lowest rainfall: Day " << minDay << " (" << minRain << " mm)\n";
}
void rainfallAfterFifth(Node* head) {
    Node* temp = head;
    int count = 1;
    while (temp && count < 6) {
        temp = temp->next;
        count++;
    }
    if (temp && temp->next) {
        cout << "Rainfall of day after 5th day: " << temp->next->rainfall << " mm\n";
    } else {
        cout << "No day exists after the 5th day.\n";
    }
}

int main() {
    Node* head = nullptr;
    double rain;
    cout << "Enter rainfall for 7 days (in mm):\n";

    for (int i = 1; i <= 7; i++) {
        do {
            cout << "Day " << i << ": ";
            cin >> rain;
            if (rain < 0) {
                cout << "Invalid input! Rainfall cannot be negative. Try again.\n";
            }
        } while (rain < 0);
        head = appendNode(head, rain);
    }

    cout << "\nWeekly Rainfall Data:\n";
    displayList(head);

    calculateStats(head);
    rainfallAfterFifth(head);

    return 0;
}
